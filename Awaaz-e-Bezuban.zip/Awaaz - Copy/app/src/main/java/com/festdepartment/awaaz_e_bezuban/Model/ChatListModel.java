package com.festdepartment.awaaz_e_bezuban.Model;

public class ChatListModel {
    public String id;

    public ChatListModel(String id) {
        this.id = id;
    }

    public ChatListModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
