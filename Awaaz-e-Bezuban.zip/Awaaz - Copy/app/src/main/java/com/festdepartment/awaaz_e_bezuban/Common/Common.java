package com.festdepartment.awaaz_e_bezuban.Common;

import com.google.firebase.firestore.auth.User;

public class Common {
    public static User currentUser;
}
