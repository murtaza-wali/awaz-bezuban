package com.festdepartment.awaaz_e_bezuban.Common;

public class Constantss {
    public static String PET_TYPE ="";
    public static String ADOPTION ="";
    public static String CHAT ="";

    public static String EMERGENCY_TYPE = "";
}
