package com.festdepartment.awaaz_e_bezuban.Notification;

public class MyResponse {

    public int success;

}
