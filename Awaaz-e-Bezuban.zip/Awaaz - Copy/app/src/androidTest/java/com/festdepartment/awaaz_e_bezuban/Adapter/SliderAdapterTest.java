package com.festdepartment.awaaz_e_bezuban.Adapter;

import junit.framework.TestCase;

public class SliderAdapterTest extends TestCase {

}